<script>

export default {
data() {
  return {
    name: 'fuqar',
    status: true,
    link: 'https://google.com',
  }
},
};
</script>

<template>
 
 <h1>{{ name }}</h1>
 <p v-if="status">user is activated</p>
 <p v-else>user unactived</p>
  <a v-bind:href="link">google</a>
</template>

<style scoped>

</style>
