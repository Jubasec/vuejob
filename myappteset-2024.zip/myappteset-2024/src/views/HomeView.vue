<script setup>
import Hero from '@/components/Hero.vue';
import HomeCards from '@/components/HomeCards.vue';
import Joblistings from '@/components/joblistings.vue';
</script>

<template>
    <Hero />
    <HomeCards />
    <Joblistings :limit="3" :show-button="true" />
</template>
