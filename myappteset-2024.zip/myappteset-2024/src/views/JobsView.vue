<script setup>
import JobListings from '@/components/joblistings.vue';
</script>

<template>
  <JobListings />
</template>
